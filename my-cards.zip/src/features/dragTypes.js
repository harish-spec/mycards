export const ItemTypes = {
    CARD: "card",
}
