
import Drawer from './Drawer'

const BucketView = () => {

  return (
    <Drawer/>
  )
}

export default BucketView